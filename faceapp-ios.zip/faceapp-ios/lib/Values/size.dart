// ignore_for_file: constant_identifier_names

part of Values;

class Sizes {
  static const double TEXT_SIZE_16 = 16.0;
  static const double TEXT_SIZE_18 = 18.0;
  static const double TEXT_SIZE_20 = 20.0;
  static const double TEXT_SIZE_22 = 22.0;
  static const double TEXT_SIZE_24 = 24.0;
  static const double TEXT_SIZE_26 = 26.0;
  static const double TEXT_SIZE_28 = 28.0;
  static const double TEXT_SIZE_30 = 30.0;
}
