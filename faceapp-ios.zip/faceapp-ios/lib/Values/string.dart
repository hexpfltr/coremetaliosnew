// ignore_for_file: constant_identifier_names

part of Values;

class StringConst {
  static const String BASE_URL = "http://86.96.196.74/coremetal";
  // http://86.96.196.74/coremetal
  static const String TOKEN = "";
  static const String USERID = "id";
  static const String API_VERSION = "/version";
  static const String LOGIN = "/oauth/token";
  static const String LOGOUT = "$BASE_URL/staff/log_out";
  static const String PROFILE = "/api/user";
  // >-----
  static const String LIST_OF_EMPLOYEES = "/api/employees";
  static const String EMPLOYEE_DETAILS = "/api/employees/details";
  static const String SET_PERSONID = "/api/employees";
  static const String ADD_FACEID = "/api/employees";
  static const String CLEAR_FACEID = "/api/employees/clear-person-ids";
  static const String CLEAR_SALESMAN_FACEID = "/api/salesman/clear-person-ids";
  static const String SET_SALESMAN_PERSONID = "/api/salesman";
  static const String ADD_SALESMAN_FACEID = "/api/salesman";
  static const String CLEAR_PERSONID = "/api/employees/clear-person-ids";
  static const String CHECK_IN = "/api/employees/add-check-in";
  static const String SALESMAN_CHECK_IN = "/api/salesman/add-check-in";
  static const String SALESMAN_CHECK_OUT = "/api/salesman/add-check-out";
  static const String MEETING_CHECK_IN = "/api/salesman/add-meeting-check-in";
  static const String MEETING_CHECK_OUT = "/api/salesman/add-meeting-check-out";
  static const String CHECK_OUT = "/api/employees/add-check-out";

  static const String GROUP_ID = "7a4d51c1-8e68-4b9e-a23b-6c7f5d92a1d3";
  static const String ACCESS_KEY = "AKIARS5H2Q5KC2LVCWYY";
  static const String SECRET_KEY = "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";
  static const String REGION = "ap-south-1";
  static const String CLIENT_SECRET =
      "FiqS53BcIaBRT61riijv9G83n8lxrsvbixm0zewc";
}
