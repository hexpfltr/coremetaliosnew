class PrintUtil {
  static void printImportant(data) {
    print(data);
  }

  static void printLog(String str) {
    print(str);
  }
}
